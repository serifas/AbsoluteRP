using AbsoluteRoleplay.Defines;
using AbsoluteRoleplay.Helpers;
using AbsoluteRoleplay.Windows.MainPanel.Views.Account;
using Dalamud.Interface;
using Dalamud.Interface.Textures;
using Dalamud.Plugin.Services;
using ImGuiNET;
using ImGuiScene;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Numerics;
using static AbsoluteRoleplay.Defines.Items;
using Dalamud.Interface.Textures.TextureWraps;
using Networking;
using OtterGui;

namespace AbsoluteRoleplay.Windows.Profiles.ProfileTabs
{
    internal class InventoryTab
    {
        private const int GridSize = 10; // 10x10 grid for 200 slots
        private const int TotalSlots = GridSize * GridSize;
        public static int? draggedSlot = null; // Slot currently being dragged

        public static Dictionary<int, Item> armorContents = new();
        public static Dictionary<int, Item> weaponContents = new();
        public static Dictionary<int, Item> materialContents = new();
        public static Dictionary<int, Item> consumableContents = new();
        public static Dictionary<int, Item> currentContents = new();

        private static int? currentTabInitialized = null; // Tracks the currently initialized tab
        public static IDalamudTextureWrap icon;
        private static bool itemCreation;
        public static int selectedItemType = 0;
        private static bool addsubtype = true;
        private static string[] itemSubType = InventoryTypes[0].Item3;
        private static int selectedSubType = 0;
        public static uint createItemIconID = 0;
        public static bool isIconBrowserOpen = false;
        public static string itemName = string.Empty;
        public static string itemDescription = string.Empty;
        public static void InitInventory(Plugin plugin)
        {
            try
            {
                icon = UI.UICommonImage(UI.CommonImageTypes.blank);
                for (int i = 0; i < TotalSlots; i++)
                {
                    var defaultItem = new Item
                    {
                        name = $"Slot {i}",
                        description = "Empty",
                        type = 0,
                        subtype = 0,
                        iconID = 0, // Default icon ID
                        slot = i
                    };

                    currentContents[i] = defaultItem;
                    armorContents[i] = defaultItem;
                    weaponContents[i] = defaultItem;
                    materialContents[i] = defaultItem;
                    consumableContents[i] = defaultItem;
                }
            }
            catch (Exception ex)
            {
               plugin.logger.Error($"InitInventory crashed: {ex.Message}\n{ex.StackTrace}");
            }
        }

        public unsafe static void LoadInventoryTab(Plugin plugin)
        {
            try
            {
                if (!itemCreation)
                {
                    if (ImGui.Button("Create Item"))
                    {
                        itemCreation = true;
                    }
                }

                if (itemCreation)
                {
                    LoadItemCreation(plugin);
                }
                else
                {
                    ImGui.BeginTabBar("ProfileNavigation");

                    if (ImGui.BeginTabItem("Armor"))
                    {
                        if (currentTabInitialized != 0)
                        {
                            currentContents = armorContents;
                            currentTabInitialized = 0;
                        }
                        ImGui.EndTabItem();
                    }
                    if (ImGui.BeginTabItem("Weapons"))
                    {
                        if (currentTabInitialized != 1)
                        {
                            currentContents = weaponContents;
                            currentTabInitialized = 1;
                        }
                        ImGui.EndTabItem();
                    }
                    if (ImGui.BeginTabItem("Materials"))
                    {
                        if (currentTabInitialized != 2)
                        {
                            currentContents = materialContents;
                            currentTabInitialized = 2;
                        }
                        ImGui.EndTabItem();
                    }
                    if (ImGui.BeginTabItem("Consumables"))
                    {
                        if (currentTabInitialized != 3)
                        {
                            currentContents = consumableContents;
                            currentTabInitialized = 3;
                        }
                        ImGui.EndTabItem();
                    }

                    ImGui.EndTabBar();

                    // Render inventory slots
                    for (int y = 0; y < GridSize; y++)
                    {
                        for (int x = 0; x < GridSize; x++)
                        {
                            int slotIndex = y * GridSize + x;

                            ImGui.PushID(slotIndex);

                            try
                            {
                                RenderInventorySlot(slotIndex, plugin);
                            }
                            catch (Exception ex)
                            {
                                plugin.logger.Error($"Error rendering slot {slotIndex}: {ex.Message}\n{ex.StackTrace}");
                                ImGui.Button("Error", new Vector2(50, 50)); // Render a fallback
                            }

                            ImGui.PopID();

                            if (x < GridSize - 1)
                                ImGui.SameLine();
                        }
                    }

                    if (!ImGui.IsMouseDown(ImGuiMouseButton.Left))
                    {
                        draggedSlot = null;
                    }
                }
            }
            catch (Exception ex)
            {
                // Ensure no silent crashes
                plugin.logger.Error($"LoadInventoryTab failed: {ex.Message}\n{ex.StackTrace}");
                throw; // Re-throw to detect crashes during testing
            }
        }

        private static unsafe void RenderInventorySlot(int slotIndex, Plugin plugin)
        {
            if (currentContents.TryGetValue(slotIndex, out var item) && item != null)
            {
                var iconHandle = WindowOperations.renderIcon(item.iconID);
                if (iconHandle != null && iconHandle.ImGuiHandle != IntPtr.Zero)
                {
                    ImGui.ImageButton(iconHandle.ImGuiHandle, new Vector2(48, 48));
                }
                else
                {
                    ImGui.Button("No Icon", new Vector2(50, 50)); // Fallback button
                }
            }
            else
            {
                ImGui.ImageButton(UI.UICommonImage(UI.CommonImageTypes.blank).ImGuiHandle, new Vector2(50, 50));
            }

            if (item != null && ImGui.BeginDragDropSource())
            {
                draggedSlot = slotIndex;
                var handle = GCHandle.Alloc(slotIndex, GCHandleType.Pinned);
                try
                {
                    ImGui.SetDragDropPayload("SLOT_MOVE", (IntPtr)handle.AddrOfPinnedObject(), sizeof(int));
                    ImGui.Text(item.name ?? "<Empty>");
                }
                finally
                {
                    handle.Free();
                }
                ImGui.EndDragDropSource();
            }

            if (ImGui.BeginDragDropTarget())
            {
                var payload = ImGui.AcceptDragDropPayload("SLOT_MOVE");
                if (payload.NativePtr != null)
                {
                    int sourceSlotIndex = Marshal.ReadInt32(payload.Data);
                    if (sourceSlotIndex != slotIndex)
                    {
                        var temp = currentContents[slotIndex];
                        currentContents[slotIndex] = currentContents[sourceSlotIndex];
                        currentContents[sourceSlotIndex] = temp;
                    }
                    draggedSlot = null;
                }
                ImGui.EndDragDropTarget();
            }
        }



        private static void LoadItemCreation(Plugin plugin)
        {
            ImGui.Image(icon.ImGuiHandle, new Vector2(50, 50));

            if (!isIconBrowserOpen)
            {
                if (ImGui.Button("Change Icon"))
                {
                    isIconBrowserOpen = true;
                }
                ImGui.Text("Name:");
                ImGui.InputTextWithHint("##Name", "Item Name", ref itemName, 100);
                ImGui.Text("Description:");
                ImGui.InputTextMultiline("##Description", ref itemDescription, 5000, new Vector2(ImGui.GetWindowSize().X - 20, ImGui.GetWindowSize().Y / 5));
                ImGui.Text("Item Type");
                AddItemCategorySelection(plugin);
                if (itemSubType != null)
                {
                    AddItemSubtypeSelection(itemSubType);
                }

                if (ImGui.Button("Create"))
                {
                    itemCreation = false;
                    DataSender.SendItemCreation(ProfileWindow.currentProfile, itemName, itemDescription, selectedItemType, selectedSubType, createItemIconID);
                }
            }
            else
            {
                if (!WindowOperations.iconsLoaded)
                {
                    WindowOperations.LoadIconsLazy(plugin);
                }

                WindowOperations.RenderIcons(plugin);
            }
        }

        public static void AddItemCategorySelection(Plugin plugin)
        {
            var (text, desc, subType) = InventoryTypes[selectedItemType];
            using var combo = OtterGui.Raii.ImRaii.Combo("##ItemCategory", text);
            ImGuiUtil.HoverTooltip(desc);
            if (!combo)
                return;

            foreach (var ((newText, newDesc, newSubtype), idx) in InventoryTypes.WithIndex())
            {
                if (ImGui.Selectable(newText, idx == selectedItemType))
                {
                    selectedItemType = idx;
                    itemSubType = InventoryTypes[idx].Item3;
                }
                ImGuiUtil.SelectableHelpMarker(newDesc);
            }
        }

        public static void AddItemSubtypeSelection(string[] subtype)
        {
            if (selectedSubType > subtype.Length)
            {
                selectedSubType = 0;
            }
            var text = subtype[selectedSubType];
            using var combo = OtterGui.Raii.ImRaii.Combo("##ItemSubtype", text);
            if (!combo)
                return;

            foreach (var (val, idx) in subtype.WithIndex())
            {
                if (ImGui.Selectable(val, idx == selectedSubType))
                {
                    selectedSubType = idx;
                }
            }
        }
    }
}
